# Master version for Pillow
__version__ = "6.2.1"
